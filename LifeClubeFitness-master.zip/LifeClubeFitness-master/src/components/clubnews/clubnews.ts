import {Component, OnInit, Renderer, ViewChild} from '@angular/core';
import {NavController} from "ionic-angular";
import {ProductProvider} from "../../providers/product/product";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

/**
 * Generated class for the ClubnewsComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'clubnews',
  templateUrl: 'clubnews.html'
})
export class ClubnewsComponent implements OnInit{

    public arr:any;
    accordionExpanded = false;
    @ViewChild("cc") cardContent:any;

    constructor(public renderer: Renderer,public navCtrl: NavController,
                public productService:ProductProvider,public http: HttpClient) {

    }

    getData(){
        let url= 'http://jsonplaceholder.typicode.com/users';
        let datae: Observable<any> = this.http.get(url);
        datae.subscribe(result => {
            this.arr=result;
            console.log(this.arr);
        });
    }
    ionViewDidLoad(){
        this.productService.getProducts();
        console.log(this.productService.getProducts());
    }

    ngOnInit(){
        console.log(this.cardContent.nativeElement);
        this.renderer.setElementStyle(this.cardContent.nativeElement, "WebkitTransition", "max-height 500ms, padding 500ms");
    }

    toggleAccordion(){
        if(this.accordionExpanded){
            this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "0px");
            this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "0px 16px");
        }else{
            this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "2000px");
            this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "13px 16px");
        }
        this.accordionExpanded= !this.accordionExpanded;
    }

}
