import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import {DashboardPage} from "../pages/dashboard/dashboard";
import {AppPreferences} from "@ionic-native/app-preferences";
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  appPref:string="appPref";
  rootPage:any = HomePage;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen,appPreference:AppPreferences) {

      appPreference.fetch(this.appPref,"login").then(res => {
        if(res){
            this.rootPage=DashboardPage;
        }else {
            this.rootPage=HomePage;
        }
      }).catch(err=>{
          console.log("error=>",err);
      });


    platform.ready().then(() => {

      statusBar.styleDefault();
      splashScreen.hide();
    });
  }
}